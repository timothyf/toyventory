// App.js (fixed)
import 'react-native-gesture-handler';
import { enableScreens } from 'react-native-screens';
enableScreens();

import React, { useEffect, useState } from 'react';
import { View, Text } from 'react-native';
import AppNavigator from './navigation/AppNavigator';
import { initDB } from './services/db';

export default function App() {
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    initDB()
      .then(() => {
        console.log('DB Initialized');
        setIsReady(true);
      })
      .catch(err => {
        console.error('DB init error:', err);
      });
  }, []);

  if (!isReady) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <Text>Loading...</Text>
      </View>
    );
  }

  return (
    <AppNavigator />
  );
}
