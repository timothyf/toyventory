import SQLite from 'react-native-sqlite-storage';

// Optional debugging (disable in production)
SQLite.enablePromise(true);
SQLite.DEBUG(true);

let db;

export async function initDB() {
  try {
    db = await SQLite.openDatabase({ name: 'figures.db', location: 'default' });

    await db.executeSql(
      `CREATE TABLE IF NOT EXISTS figures (
        id INTEGER PRIMARY KEY NOT NULL,
        name TEXT NOT NULL,
        series TEXT,
        year INTEGER,
        manufacturer TEXT,
        purchase_price REAL,
        notes TEXT,
        photo_uri TEXT
      );`
    );

    console.log('Figures table created or already exists');
  } catch (error) {
    console.error('Error initializing DB:', error);
    throw error;
  }
}

export function getDB() {
  return db;
}

export function insertFigure(name, series, year, manufacturer, purchasePrice, notes, photoUri) {
  return db.executeSql(
    `INSERT INTO figures (name, series, year, manufacturer, purchase_price, notes, photo_uri)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [name, series, year, manufacturer, purchasePrice, notes, photoUri]
  );
}

export function fetchFigures() {
  return db.executeSql('SELECT * FROM figures;')
    .then(([result]) => result.rows.raw());
}

export function fetchFigureById(id) {
  return db.executeSql('SELECT * FROM figures WHERE id = ?;', [id])
    .then(([result]) => result.rows.length > 0 ? result.rows.item(0) : null);
}

export function updateFigure(id, name, series, year, manufacturer, purchasePrice, notes, photoUri) {
  return db.executeSql(
    `UPDATE figures SET name = ?, series = ?, year = ?, manufacturer = ?, purchase_price = ?, notes = ?, photo_uri = ? WHERE id = ?;`,
    [name, series, year, manufacturer, purchasePrice, notes, photoUri, id]
  );
}

export function deleteFigure(id) {
  return db.executeSql('DELETE FROM figures WHERE id = ?;', [id]);
}
