// AddEditFigureScreen.js (Now loads existing figure data safely and updates header title)
import React, { useState, useEffect } from 'react';
import { View, TextInput, Button, StyleSheet, Text, Image, Alert, ScrollView, Dimensions } from 'react-native';
import ImagePicker from 'react-native-image-crop-picker';
import { getDB } from '../services/db';

const screenWidth = Dimensions.get('window').width;

export default function AddEditFigureScreen({ navigation, route }) {
  const editingFigureId = route?.params?.id;

  const [formData, setFormData] = useState({
    name: '',
    series: '',
    year: '',
    manufacturer: '',
    purchasePrice: '',
    notes: '',
    photoUri: ''
  });

  useEffect(() => {
    navigation.setOptions({ title: editingFigureId ? 'Edit Figure' : 'Add New Figure' });

    if (editingFigureId) {
      const db = getDB();
      db.transaction(tx => {
        tx.executeSql(
          `SELECT * FROM figures WHERE id = ?;`,
          [editingFigureId],
          (_, { rows }) => {
            if (!rows || rows.length === 0) {
              console.log('No figure found for editing');
              navigation.goBack();
              return;
            }
            const figure = rows._array[0];
            setFormData({
              name: figure.name || '',
              series: figure.series || '',
              year: figure.year?.toString() || '',
              manufacturer: figure.manufacturer || '',
              purchasePrice: figure.purchase_price?.toString() || '',
              notes: figure.notes || '',
              photoUri: figure.photo_uri || ''
            });
          },
          (txObj, error) => {
            console.error('Error loading figure:', error);
          }
        );
      });
    }
  }, [editingFigureId, navigation]);

  const pickImage = async () => {
    try {
      const result = await ImagePicker.openPicker({
        width: 800,
        height: 800,
        cropping: true,
        compressImageQuality: 0.8,
        mediaType: 'photo',
      });
  
      if (result && result.path) {
        setFormData(prev => ({ ...prev, photoUri: result.path }));
      }
    } catch (error) {
      if (error.code !== 'E_PICKER_CANCELLED') {
        console.error('ImagePicker Error:', error);
        Alert.alert('Error', 'Failed to pick image');
      }
    }
  };
  

  const handleSave = () => {
    console.log('Save button pressed');
    const db = getDB();
    db.transaction(tx => {
      tx.executeSql(
        `INSERT INTO figures (name, series, year, manufacturer, purchase_price, notes, photo_uri) VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [
          formData.name,
          formData.series,
          parseInt(formData.year) || null,
          formData.manufacturer,
          parseFloat(formData.purchasePrice) || null,
          formData.notes,
          formData.photoUri
        ],
        () => {
          console.log('Figure saved successfully');
          Alert.alert('Success', 'Figure saved!');
          navigation.goBack();
        },
        (txObj, error) => {
          console.error('Error saving figure:', error);
          Alert.alert('Save Error', 'There was an error saving the figure.');
          return false;
        }
      );
    });
  };

  const handleDelete = () => {
    if (!editingFigureId) return;

    const db = getDB();
    db.transaction(tx => {
      tx.executeSql(
        `DELETE FROM figures WHERE id = ?;`,
        [editingFigureId],
        () => {
          console.log('Figure deleted successfully');
          Alert.alert('Deleted', 'Figure deleted!');
          navigation.goBack();
        },
        (txObj, error) => {
          console.error('Error deleting figure:', error);
          Alert.alert('Delete Error', 'There was an error deleting the figure.');
          return false;
        }
      );
    });
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text>Name</Text>
      <TextInput
        style={styles.input}
        value={formData.name}
        onChangeText={text => setFormData({ ...formData, name: text })}
      />
      <Text>Series</Text>
      <TextInput
        style={styles.input}
        value={formData.series}
        onChangeText={text => setFormData({ ...formData, series: text })}
      />
      <Text>Year</Text>
      <TextInput
        style={styles.input}
        value={formData.year}
        onChangeText={text => setFormData({ ...formData, year: text })}
        keyboardType="numeric"
      />
      <Text>Manufacturer</Text>
      <TextInput
        style={styles.input}
        value={formData.manufacturer}
        onChangeText={text => setFormData({ ...formData, manufacturer: text })}
      />
      <Text>Purchase Price</Text>
      <TextInput
        style={styles.input}
        value={formData.purchasePrice}
        onChangeText={text => setFormData({ ...formData, purchasePrice: text })}
        keyboardType="numeric"
      />
      <Text>Notes</Text>
      <TextInput
        style={styles.input}
        value={formData.notes}
        onChangeText={text => setFormData({ ...formData, notes: text })}
      />

      {formData.photoUri ? (
        <View style={{ alignItems: 'center' }}>
          <Image
            source={{ uri: formData.photoUri }}
            style={{ width: screenWidth * 0.8, height: screenWidth * 0.8, marginVertical: 16, borderRadius: 8 }}
          />
          <Button title="Change Photo" onPress={pickImage} />
        </View>
      ) : (
        <Button title="Pick a Photo" onPress={pickImage} />
      )}

      <Button title="Save Figure" onPress={handleSave} />

      {editingFigureId && (
        <Button
          title="Delete Figure"
          color="red"
          onPress={() => {
            Alert.alert('Confirm Delete', 'Are you sure you want to delete this figure?', [
              { text: 'Cancel', style: 'cancel' },
              { text: 'Delete', style: 'destructive', onPress: handleDelete },
            ]);
          }}
        />
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flexGrow: 1, padding: 20, backgroundColor: '#fff' },
  input: { borderWidth: 1, borderColor: '#ccc', padding: 10, marginBottom: 10, borderRadius: 6 }
});
