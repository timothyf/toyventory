// CollectionListScreen.js (fixed)
import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, TouchableOpacity, Image, StyleSheet } from 'react-native';
import { fetchFigures } from '../services/db';

export default function CollectionListScreen({ navigation }) {
  const [figures, setFigures] = useState([]);

  useEffect(() => {
    const loadFigures = async () => {
      try {
        const data = await fetchFigures();
        if (Array.isArray(data)) {
          setFigures(data.filter(item => item && item.id));
        } else {
          setFigures([]);
        }
      } catch (err) {
        console.error('Failed to load figures:', err);
        setFigures([]);
      }
    };

    const unsubscribe = navigation.addListener('focus', loadFigures);
    return unsubscribe;
  }, [navigation]);

  const renderItem = ({ item }) => {
    if (!item || !item.id) return null;

    return (
      <TouchableOpacity onPress={() => navigation.navigate('Detail', { id: item.id })}>
        <View style={styles.item}>
          {item.photo_uri ? (
            <Image source={{ uri: item.photo_uri }} style={styles.thumbnail} />
          ) : null}
          <View>
            <Text style={styles.name}>{item.name}</Text>
            <Text style={styles.meta}>{item.manufacturer} • {item.year}</Text>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <View style={styles.container}>
      <View style={{ flex: 1 }}>
        {figures.length > 0 ? (
          <FlatList
            data={figures}
            keyExtractor={(item, index) => item?.id?.toString() || `item-${index}`}
            renderItem={renderItem}
          />
        ) : (
          <View style={styles.emptyContainer}>
            <Text>No figures found. Add a new one!</Text>
          </View>
        )}
      </View>
      <TouchableOpacity
        style={styles.addButton}
        onPress={() => navigation.navigate('AddEdit')}
      >
        <Text style={styles.addButtonText}>+ Add Figure</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#fff' },
  emptyContainer: { justifyContent: 'center', alignItems: 'center', paddingVertical: 20 },
  item: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },
  thumbnail: {
    width: 48,
    height: 48,
    borderRadius: 8,
    marginRight: 12,
  },
  name: { fontSize: 18, fontWeight: 'bold' },
  meta: { color: '#666' },
  addButton: {
    backgroundColor: '#007AFF',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 16,
  },
  addButtonText: { color: '#fff', fontWeight: 'bold' },
});