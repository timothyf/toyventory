// StatsScreen.js
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function StatsScreen() {
  const stats = {
    totalFigures: 150,
    totalValue: '$3,250.00',
    byManufacturer: [
      { name: 'Kenner', count: 60 },
      { name: 'Mattel', count: 45 },
      { name: 'Hasbro', count: 30 },
      { name: 'Other', count: 15 }
    ]
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Collection Summary</Text>
      <Text style={styles.stat}>Total Figures: {stats.totalFigures}</Text>
      <Text style={styles.stat}>Total Value: {stats.totalValue}</Text>
      <Text style={styles.subtitle}>By Manufacturer:</Text>
      {Array.isArray(stats.byManufacturer) && stats.byManufacturer.map((item, index) => (
        <Text key={index} style={styles.manufacturer}>{item.name}: {item.count}</Text>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#fff' },
  title: { fontSize: 22, fontWeight: 'bold', marginBottom: 16 },
  stat: { fontSize: 18, marginBottom: 8 },
  subtitle: { fontSize: 20, marginTop: 16, marginBottom: 8 },
  manufacturer: { fontSize: 16, marginLeft: 12 },
});
